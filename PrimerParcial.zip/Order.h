#pragma once
#include <iostream>
#include <string>
using namespace std; 
class Order
{
private:
    int idproducto;
    int idpedido;
    int total;
    string cliente;
public:
    Order();
    int anadir_prod(int producto);
};

