#include "Order.h"
#include <string>
Order::Order() {
    idproducto = 0;
}
int Order::anadir_prod(int producto) {
    idproducto = producto;
}
