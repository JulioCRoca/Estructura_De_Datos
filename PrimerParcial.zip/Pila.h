#pragma once
#include <iostream>
#define MAX 100
using namespace std; 
 
class Pila
{
	private:
		int i[MAX]; 
		int cima; 
	public:
		Pila(); 
		bool apilar(int nro); 
		bool esta_vacia();
};

