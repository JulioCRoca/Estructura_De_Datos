#include <iostream>
#include <string>
#include "Pila.h"
#include "Order.h"
using namespace std; 

float potencia(int a, int b); 
int main()
{
    int a, b,nro,opcion,poten,n,producto; 
    Pila pilita;
    Order ordencita; 
    do {
        cout << "======Menu======" << endl; 
        cout << "1. Recursiva potencia" << endl; 
        cout << "2. ¨Pila de impares" << endl;
        cout << "3. Clase order" << endl;
        cout << "0. Salir" << endl;
        cin >> opcion; 
        switch (opcion) {
        case 1: 
            cout << "Ingrese la base de la operacion: ";
            cin >> a;
            cout << "Ingrese la potencia b: "; 
            cin >> b; 
            poten = potencia(a, b);
            cout << "La potencia es: " << poten; 
            break; 
        case 2: 
            cout << "Ingrese la cantidad de numeros impares a apilar"; 
            cin >> n;
            for (int i = 1;i<= n; i++) {
                int impar = (2 * i) + 1; 
                pilita.apilar(impar); 
            }
            break; 
        case 3:
            cout << "Ingre el id del producto: "; 
            cin >> producto; 
            ordencita.anadir_prod(producto); 
            break; 
        case 0: 
            cout << "Saliendoooo...."; 
            break; 
        default: 
            cout << "Ingrese una opcion valida"; 
        }
    } while (opcion != 0);
    return 0; 
}
float potencia(int a, int b) {
    if (b == 0) {
        return 1; 
    }
    else {
        return a * potencia(a, b - 1); 
    }




}
