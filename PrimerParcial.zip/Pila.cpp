#include "Pila.h"
Pila::Pila() {
	cima = -1; 
}
bool Pila::apilar(int nro) {
	if (cima == -1)
		return false;
	else
		cima++; 
		i[cima]= nro;
		return true; 
}
bool Pila::esta_vacia() {
	if (cima == -1) {
		return true; 
	}
	else {
		return false; 
	}
}