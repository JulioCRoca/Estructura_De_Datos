#pragma once
#define MAX 100
#include <string>
using namespace std; 

class Colae
{ private: 
	string info[MAX]; 
	int ini, fin;
 public: 
	Colae (void); 
	bool Encolar (string Valor); 
	bool Desencolar (void); 
	bool PrimeroCola (string &Valor); 
	bool ColaVacia (void);
	void mostrar (void);
};


