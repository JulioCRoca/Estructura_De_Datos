#include <iostream>
#include <string>
#include "Matriz.h"
#include "Fila.h"
using namespace std;
#define MAX 10
// Función que genera la matriz final a partir del "vector de vectores"
void procesarDatos(Fila entrada[], int n, Matriz& salida) {
    int filaSalida = 0;
    for (int i = 0; i < n; i++) {        // recorrer filas de entrada
        for (int j = 0; j < n; j++) {    // recorrer columnas
            int valor = entrada[i].get(j);
            for (int k = 0; k < n; k++) {
                salida.setDato(filaSalida, k, valor);
            }
            filaSalida++;
        }
    }
}
int sumaelemento(Fila entrada[], int n, Matriz& salida) {
    int suma = 0; 
    for (int i = 0; i < n * n; i++) {
        for (int j = 0; j < n; j++) {
            suma +=salida.getDato(i, j);
        }
    }
    return suma; 
}

int main() {
    const int n = 3;
    Fila entrada[MAX];
    int sumatot; 

    // Cargamos los datos manualmente en entrada
    entrada[0].set(0, 1); entrada[0].set(1, 2); entrada[0].set(2, 3);
    entrada[1].set(0, 4); entrada[1].set(1, 5); entrada[1].set(2, 6);
    entrada[2].set(0, 7);  entrada[2].set(1, 8); entrada[2].set(2, 9);

    // Creamos matriz de salida n*n
    Matriz salida(n * n, n);

    procesarDatos(entrada, n, salida);

    cout << "Matriz Generada:" << endl;
    salida.mostrar();
    sumatot = sumaelemento(entrada, n, salida); 
    cout << "La suma total es: " << sumatot; 

    return 0;
}