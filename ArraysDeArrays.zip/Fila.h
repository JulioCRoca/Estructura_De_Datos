#pragma once 
#include <string>
#include <iostream>
using namespace std; 
#define MAX 10
class Fila {
private:
    int elementos[MAX];

public:
    void set(int i, int valor) {
        elementos[i] = valor;
    }

    int get(int i) {
        return elementos[i];
    }

    void mostrar(int n) {
        for (int i = 0; i < n; i++) {
            cout << elementos[i] << "\t";
        }
        cout << endl;
    }
};
