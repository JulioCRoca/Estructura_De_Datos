// cola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include <iostream>
#include "Colae.h"

#define MAX 100

using namespace std;

void main()
{
	Colae cola;
	int option;
	char word,valor; 
	do{
		cout << "1.Cola Vacia?" << endl;
		cout << "2.Encolar" << endl;
		cout << "3.Desencolar" << endl;
		cout << "4.Primero cola" << endl;
		cout << "5.Mostrar" << endl;
		cout << "0.Salir" << endl;
		cout << "Ingrese una opcion: "; 
		cin >> option; 
		switch (option){
			case 1:
				if (cola.ColaVacia())
					cout << "La cola esta vacia" << endl;
				else
					cout << "La cola no esta vacia" << endl; 
				break; 
			case 2: 
				cout << "Ingrese la palabra a encolar:"; 
				cin >> word;
				if (!cola.Encolar(word))
					cout << "Encolado con exito" << endl; 
				else
					cout << "Error al encolar" << endl; 
				break; 
			case 3: 
				if (cola.Desencolar())
					cout << "Error no se desencolo" << endl;
				else
					cout << "Desencolado con exito" << endl; 
				break; 
			case 4: 
				if (cola.PrimeroCola(word))
					cout << "Cola vacia" << endl; 
				else
					cout << "El primero de la cola es:" << word	<< endl; 
				break; 
			case 5: 
				cola.mostrar();
				break; 
			case 0: 
				cout << "Saliendo.....";
			default:
				if (option < 0)
					cout << "Ingrese una opci�n v�lida" << endl; 
				break;
		}
	} while (option != 0);
	/*for (int j = 1; j<10; j++)
		if (!cola.Encolar(j)) 
			cola.mostrar();
		else
			cout<<"Error";
	cout<<endl<<"Desencolar"<<endl;
	if (!cola.Desencolar())
		cola.mostrar();
	else
		cout<<"Error";
	if (!cola.PrimeroCola(Valor))
		cout<<"Valor: "<<Valor;
		*/
	getch();
}