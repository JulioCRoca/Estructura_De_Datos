#pragma once
#define MAX 100
#include <string>

class Colae
{ private: 
	char info[MAX]; 
	int ini, fin;
 public: 
	Colae (void); 
	bool Encolar (char Valor); 
	bool Desencolar (void); 
	bool PrimeroCola (char &Valor); 
	bool ColaVacia (void);
	void mostrar (void);
};


