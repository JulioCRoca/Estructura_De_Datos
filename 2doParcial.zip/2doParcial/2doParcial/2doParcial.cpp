#include <iostream>
#include <iostream>
#include "Numeros.h"
using namespace std; 
int main()
{
    int opcion,numeros;
    Numeros numerito; 
    do {
        cout << "====MENU====" << endl; 
        cout << "1. Ejercicio 1" << endl; 
        cout << "2. Ejercicio 2" << endl;
        cout << "3. Ejercicio 3" << endl;
        cout << "0. Salir" << endl;
        cout << "Elija una opcion: "; 
        cin >> opcion;
        switch (opcion) {
        case 1: 
            do {
                cout << "Ingrese la cantidad de nros primos: "; 
                cin >> numeros; 
            } while (numeros <= 0); 
            numerito.cargar(numeros);  
            break; 
        case 2: 
            break; 
        case 3: 
            break; 
        default:
            break; 
        }
    } while (opcion != 0); 
}


