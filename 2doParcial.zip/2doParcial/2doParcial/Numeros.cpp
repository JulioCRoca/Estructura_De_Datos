#include "Numeros.h"
#include <iostream>
#include "Math.h"
using namespace std; 
Numeros::Numeros() {
	int cantidad = 0; 
}
bool Numeros::Esprimo(int n) {
	for (int i = 2; i <= sqrt(n); i++) {
		if (n % i == 0) 
			return false; 
		 
	}
	return true;
}
void Numeros::cargar(int n) {
	int pos = 0; 
	for (int i = 2; i < MAX; i++) {
		if(Esprimo(i)){
			primos[pos] = i;
			if (pos <= n) {
				return; 
			}
			pos++; 
		}
	}
	cantidad = n; 
	Mostrar(cantidad); 

}
void Numeros::Mostrar(int n) {
	for (int i = 0; i < n; i++) {
		cout << primos[i] << "\t Cuadrado: " << primos[i]* primos[i] << " Cubo: " << primos[i] * primos[i] * primos[i] << endl;
	}
}