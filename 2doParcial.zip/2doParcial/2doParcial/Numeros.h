#pragma once
#define MAX 100 
class Numeros
{
	private: 
		int primos[MAX]; 
		int cantidad; 
	public: 
		Numeros(); 
		bool Esprimo(int n); 
		void cargar(int n); 
		void Mostrar(int n); 
};

