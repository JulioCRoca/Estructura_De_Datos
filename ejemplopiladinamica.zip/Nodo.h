
#pragma once
#include <string>

using namespace std;

class Nodo
{
	public:
		int dato;
		string nombre;
		string artista; 
		Nodo* sig;
	};

