// ConsoleApplication1.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
#include <string>
#include "pilas.h"
using namespace std; 

int main()
{
    string dato; 
    int opcion; 
    do {
    
        cout << "=====Menu=====" << endl; 
        cout << "1. Rehacer cambio" << endl; 
        cout << "2. Deshacer cambio" << endl; 
        cout << "3. Mostrar ultimo cambio" << endl;
        cout << "4. Realiza cambio" << endl; 
        cout << "0. Salir del programa" << endl; 
        cin >> opcion;
        if (opcion < 0) {
            cout << "Elija una opcion valida" << endl;
        }
        switch (opcion) {
        case1: 
            break; 
        case2: 
            break; 
        case3: 
            break; 
        case4: 
            break; 
        case0: 
            break; 
        default: 
            cout << "Ingrese una opcion valida" << endl; 
        }
    } while (opcion!=0);
}
