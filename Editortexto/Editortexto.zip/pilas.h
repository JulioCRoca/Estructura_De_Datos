#pragma once
#include <iostream>
#include <string>
#include "nodo.h"
#define MAX 100
using namespace std; 
class pilas
{
	private: 
		nodo cambios[MAX];
		nodo rehacerpila[MAX]; 
		int cima2; 
		int cima; 
	public:
		pilas(); 
		bool realizarCambio(string &new_cambio); 
		bool deshacer(); 
		bool rehacer(); 
		bool verUltimoCambio(); 
		bool estaVacia(); 
		
};

