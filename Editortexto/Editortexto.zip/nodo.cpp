#include "nodo.h"
#include <string>
#include <iostream>
using namespace std;

nodo::nodo() {
	cambio = "";
}
nodo::nodo(string estado) {
	cambio = estado; 
}
