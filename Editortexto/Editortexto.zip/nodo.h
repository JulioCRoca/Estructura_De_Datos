#pragma once
#include <string.h>
#include <iostream>

using namespace std; 
class nodo
{
	public:
		string cambio;  
		nodo(); 
		nodo(string estado); 
};

