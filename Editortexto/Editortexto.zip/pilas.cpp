#include "pilas.h"
#include <iostream>
#include <string>
using namespace std; 
pilas::pilas() {
	 cima = -1;
	 cima2 = -1; 
}

bool pilas::estaVacia() {
	bool estado = false; 
	if (cima == -1) {
		estado = true; 
		return estado; 
	}
	else {
		return estado; 
	}
}
bool pilas::realizarCambio(string& new_cambio) {
	if (cima == MAX - 1) {
		cout << "Overflow de pila " << endl;
		return false;
	}
	else {
		cima++;
		cambios[cima].cambio = new_cambio;
		return true;
	}
}
bool pilas::deshacer() {
	if (cima==-1) {
		cout << "No es posible realizar ningun cambio" << endl; 
		return false; 
	}
	else {
		cima--;
		return true; 
		cima2++; 
		rehacerpila[cima2].cambio = cambios[cima].cambio;
		cambios[cima].cambio = "";
	}
}

bool pilas::rehacer(){
	if (cima == MAX - 1) {
		cout << "No es posible rehacer algun cambio" << endl; 
		return false; 
	}
	else {
		cima++;
		cambios[cima].cambio = rehacerpila[cima2].cambio; 
		rehacerpila[cima2].cambio = ""; 
		cima2--; 
		return true; 
	}
}
bool pilas::verUltimoCambio() {
	if (estaVacia()) {
		cout << "No se puede mostrar el ultimo cambio, la pila esta vacia" << endl; 
		return false; 
	}
	else {
		cout << "el ultimo cambio del texto fue" << cambios[cima].cambio << endl; 
	}

}
